AlphaMiner Windows GPU+Hybrid v1.0.2nLaunch:nAlphaMiner.exe YOUR_QUBIC_ID rig-hybrid-win01 0 qubic.alphapool.tech 7777n
